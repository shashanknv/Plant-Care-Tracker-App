function trackPlant(plantName) {
    alert("Tracking growth of " + plantName + "!");
}

function trackSelectedPlant() {
    var selectedPlant = document.getElementById("plantSelect").value;
    alert("Tracking growth of " + selectedPlant + "!");
}